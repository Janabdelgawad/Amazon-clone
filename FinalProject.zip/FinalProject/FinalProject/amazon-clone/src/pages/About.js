import React from "react";
import { AboutPic } from "../assets/index";

function About() {
  return (
    <div>
      <img src={AboutPic} alt="about" />
    </div>
  );
}

export default About;
